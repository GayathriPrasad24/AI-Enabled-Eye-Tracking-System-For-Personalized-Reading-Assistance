# app.py
"""
Production Eye Tracking — v6 (Enhanced with XGBoost, Temporal Stability, Attention AI)
====================================================================================
All modules consolidated into one file.

Key improvements:
- XGBoost model integration with ensemble prediction (Ridge + XGBoost + MLP)
- Advanced feature engineering (iris velocity, eye center, distance, angle)
- Temporal stability with 5-frame prediction buffer
- Attention AI system with focus tracking
- Blink/fatigue detection using EAR
- Improved head compensation using nose deviation
- Enhanced calibration robustness
- 95%+ accuracy target

Run:
    python app.py

Requirements:
    pip install flask flask-socketio gevent gevent-websocket mediapipe
                opencv-python numpy scikit-learn scipy xgboost
    # optional document support:
    pip install PyMuPDF python-docx
"""

from __future__ import annotations

# ── gevent monkey-patch MUST be the very first thing ───────────────
from gevent import monkey
monkey.patch_all()

import base64
import csv
import io
import logging
import math
import os
import pickle
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Any

import cv2
import mediapipe as mp
import numpy as np
from flask import Flask, jsonify, render_template, request, send_file
from flask_socketio import SocketIO, emit
from scipy.spatial.distance import mahalanobis
from sklearn.linear_model import Ridge
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from xgboost import XGBRegressor

try:
    import fitz
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

try:
    from docx import Document as DocxDocument
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

# ── Logging ────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
logger = logging.getLogger("GazeTracker")

# Helper to convert numpy types to Python native types for JSON serialization
def convert_to_serializable(obj):
    """Convert numpy types to Python native types."""
    if isinstance(obj, np.floating):
        return float(obj)
    elif isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {k: convert_to_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_to_serializable(item) for item in obj]
    elif isinstance(obj, tuple):
        return tuple(convert_to_serializable(item) for item in obj)
    return obj

# ══════════════════════════════════════════════════════════════════
# SECTION 1 — FILTERS (Optimized for Smoothness)
# ══════════════════════════════════════════════════════════════════


class AdaptiveKalman:
    """4-state (x, y, vx, vy) / 2-measurement Kalman filter with reduced sensitivity."""
    
    # Reduced values for smoother movement
    Q_BASE = 1e-4
    Q_HIGH = 2e-3  # Reduced from 8e-3 for less aggressive tracking
    R_BASE = 0.15
    R_LOW = 0.02
    VEL_THR = 0.04

    def __init__(self) -> None:
        self._kf = cv2.KalmanFilter(4, 2)
        self._kf.measurementMatrix = np.array(
            [[1, 0, 0, 0],
             [0, 1, 0, 0]], np.float32)
        self._kf.transitionMatrix = np.array(
            [[1, 0, 1, 0],
             [0, 1, 0, 1],
             [0, 0, 1, 0],
             [0, 0, 0, 1]], np.float32)
        self._initialized = False
        self._last_vel = 0.0
        self._reset_noise(0.0)

    def update(self, x: float, y: float) -> Tuple[float, float]:
        meas = np.array([[np.float32(x)], [np.float32(y)]])
        if not self._initialized:
            self._kf.statePost = np.array(
                [[x], [y], [0.0], [0.0]], np.float32)
            self._kf.errorCovPost = np.eye(4, dtype=np.float32) * 0.1
            self._initialized = True

        vx = float(self._kf.statePost[2, 0])
        vy = float(self._kf.statePost[3, 0])
        vel = math.hypot(vx, vy)
        self._last_vel = vel
        self._reset_noise(vel)
        self._kf.correct(meas)
        pred = self._kf.predict()
        return float(pred[0, 0]), float(pred[1, 0])

    def reset(self) -> None:
        self._initialized = False
        self._last_vel = 0.0

    @property
    def velocity(self) -> float:
        return self._last_vel

    def _reset_noise(self, vel: float) -> None:
        t = min(vel / self.VEL_THR, 1.0)
        q = self.Q_BASE + t * (self.Q_HIGH - self.Q_BASE)
        r = max(self.R_BASE + (1 - t) * (self.R_LOW - self.R_BASE), 0.01)
        self._kf.processNoiseCov = np.eye(4, dtype=np.float32) * q
        self._kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * r


class AdaptiveEMA:
    """Exponential Moving Average with reduced alpha values for smoother tracking."""
    
    def __init__(
        self,
        alpha_slow: float = 0.02,  # Reduced from 0.08 for slower response
        alpha_fast: float = 0.18,   # Reduced from 0.40
        vel_mid: float = 0.03,
        vel_scale: float = 60.0,
    ) -> None:
        self.alpha_slow = alpha_slow
        self.alpha_fast = alpha_fast
        self.vel_mid = vel_mid
        self.vel_scale = vel_scale
        self._x: Optional[float] = None
        self._y: Optional[float] = None

    def update(self, x: float, y: float, velocity: float) -> Tuple[float, float]:
        t = 1.0 / (1.0 + math.exp(-self.vel_scale * (velocity - self.vel_mid)))
        alpha = self.alpha_slow + t * (self.alpha_fast - self.alpha_slow)
        if self._x is None:
            self._x, self._y = x, y
        else:
            self._x = alpha * x + (1.0 - alpha) * self._x
            self._y = alpha * y + (1.0 - alpha) * self._y
        return self._x, self._y

    def reset(self) -> None:
        self._x = self._y = None


class VelocityDamper:
    """Hard-limit single-frame screen-space jumps with reduced thresholds."""
    
    def __init__(self, max_jump: float = 0.08, blend: float = 0.2) -> None:  # Reduced thresholds
        self.max_jump = max_jump
        self.blend = blend
        self._prev_x: Optional[float] = None
        self._prev_y: Optional[float] = None

    def update(self, x: float, y: float) -> Tuple[float, float]:
        if self._prev_x is None:
            self._prev_x, self._prev_y = x, y
            return x, y
        dx, dy = x - self._prev_x, y - self._prev_y
        dist = math.hypot(dx, dy)
        if dist > self.max_jump:
            x = self._prev_x + self.blend * dx
            y = self._prev_y + self.blend * dy
        self._prev_x, self._prev_y = x, y
        return x, y

    def reset(self) -> None:
        self._prev_x = self._prev_y = None


class DeadZoneGate:
    """Only update published gaze when change exceeds threshold."""
    
    def __init__(self, threshold: float = 0.01) -> None:  # Increased threshold
        self.threshold = threshold
        self._gx: float = 0.5
        self._gy: float = 0.5

    def update(self, x: float, y: float) -> Tuple[float, float]:
        if math.hypot(x - self._gx, y - self._gy) > self.threshold:
            self._gx, self._gy = x, y
        return self._gx, self._gy

    def reset(self) -> None:
        self._gx, self._gy = 0.5, 0.5


class FinalSmoothing:
    """Additional smoothing with exponential moving average."""
    
    def __init__(self, alpha: float = 0.15):
        self.alpha = alpha
        self._smooth_x: Optional[float] = None
        self._smooth_y: Optional[float] = None
        
    def update(self, x: float, y: float) -> Tuple[float, float]:
        if self._smooth_x is None:
            self._smooth_x, self._smooth_y = x, y
        else:
            self._smooth_x = (1.0 - self.alpha) * self._smooth_x + self.alpha * x
            self._smooth_y = (1.0 - self.alpha) * self._smooth_y + self.alpha * y
        return self._smooth_x, self._smooth_y
    
    def reset(self) -> None:
        self._smooth_x = self._smooth_y = None


class FrameSkipFilter:
    """Only update gaze every N frames for stabilization."""
    
    def __init__(self, skip_frames: int = 2):
        self.skip_frames = skip_frames
        self.counter = 0
        
    def should_update(self) -> bool:
        self.counter += 1
        if self.counter >= self.skip_frames:
            self.counter = 0
            return True
        return False


@dataclass
class Fixation:
    """Represents a single fixation event."""
    x: float
    y: float
    start_time: float
    end_time: float
    duration: float
    position_x: float = 0.0
    position_y: float = 0.0


class FixationDetector:
    """Declares fixation when gaze stays within radius for min_frames."""
    
    def __init__(
        self,
        radius: float = 0.04,
        min_frames: int = 8,
        max_frames: int = 60,
        time_window: float = 0.5,
    ) -> None:
        self.radius = radius
        self.min_frames = min_frames
        self.time_window = time_window
        self._buf: deque = deque(maxlen=max_frames)
        self._timestamps: deque = deque(maxlen=max_frames)
        self._current_fixation: Optional[Fixation] = None
        self.fixations: List[Fixation] = []
        self._last_fixation_end = 0.0
        self.is_fixating = False
        self.current_fixation_point: Optional[Tuple[float, float]] = None

    def update(
        self, x: float, y: float, timestamp: float
    ) -> Tuple[bool, Optional[Tuple[float, float]]]:
        if self._buf:
            cx = sum(p[0] for p in self._buf) / len(self._buf)
            cy = sum(p[1] for p in self._buf) / len(self._buf)
            if math.hypot(x - cx, y - cy) > self.radius:
                self._end_current_fixation(timestamp)
                self._buf.clear()
                self._timestamps.clear()
                self.is_fixating = False
                self.current_fixation_point = None

        self._buf.append((x, y))
        self._timestamps.append(timestamp)

        if len(self._buf) >= self.min_frames and not self.is_fixating:
            cx = sum(p[0] for p in self._buf) / len(self._buf)
            cy = sum(p[1] for p in self._buf) / len(self._buf)
            self._current_fixation = Fixation(
                x=cx, y=cy,
                start_time=self._timestamps[0],
                end_time=timestamp,
                duration=0,
                position_x=cx,
                position_y=cy
            )
            self.is_fixating = True
            self.current_fixation_point = (cx, cy)

        if self.is_fixating and self._current_fixation is not None:
            self._current_fixation.end_time = timestamp
            self._current_fixation.duration = timestamp - self._current_fixation.start_time
            cx = sum(p[0] for p in self._buf) / len(self._buf)
            cy = sum(p[1] for p in self._buf) / len(self._buf)
            self._current_fixation.x = cx
            self._current_fixation.y = cy
            self._current_fixation.position_x = cx
            self._current_fixation.position_y = cy
            self.current_fixation_point = (cx, cy)
            return True, (cx, cy)

        return False, None

    def _end_current_fixation(self, timestamp: float) -> None:
        if self._current_fixation is not None:
            self._current_fixation.end_time = timestamp
            self._current_fixation.duration = timestamp - self._current_fixation.start_time
            self.fixations.append(self._current_fixation)
            self._current_fixation = None
            self._last_fixation_end = timestamp
        self.is_fixating = False
        self.current_fixation_point = None

    def reset(self) -> None:
        self._buf.clear()
        self._timestamps.clear()
        self._current_fixation = None
        self.fixations.clear()
        self._last_fixation_end = 0.0
        self.is_fixating = False
        self.current_fixation_point = None


class ReadingAnalytics:
    """Track reading-specific metrics using local reading-area coordinates.
    
    Enhanced with attention AI system that tracks focused time and attention score.
    """
    
    def __init__(
        self,
        saccade_velocity_threshold: float = 0.06,
        line_change_threshold: float = 0.10,  # Increased for better stability
        reading_velocity_range: Tuple[float, float] = (0.01, 0.08),
        words_per_line: int = 10,
    ) -> None:
        self.saccade_velocity_threshold = saccade_velocity_threshold
        self.line_change_threshold = line_change_threshold
        self.reading_velocity_min, self.reading_velocity_max = reading_velocity_range
        self.words_per_line = words_per_line

        self._last_position: Optional[Tuple[float, float]] = None
        self._last_timestamp: float = 0.0
        self._last_velocity: float = 0.0
        self._current_line_y: float = 0.0
        self._line_changes: int = 0
        self._saccades: int = 0
        self._left_to_right_movements: int = 0
        self._reading_time: float = 0.0
        self._reading_active: bool = False
        self._reading_start_time: float = 0.0
        self._movement_history: deque = deque(maxlen=50)
        self._pending_line_change: bool = False
        
        # Attention AI System
        self._total_time: float = 0.0
        self._focused_time: float = 0.0
        self._last_update_time: float = 0.0
        self._attention_score: float = 0.0
        self._blink_count: int = 0
        self._fatigue_score: float = 0.0

    def update(self, x: float, y: float, velocity: float, timestamp: float, is_fixation: bool = False, ear: float = 1.0) -> Dict[str, Any]:
        analytics = {
            "saccade_detected": False,
            "line_changed": False,
            "left_to_right": False,
            "reading_speed": 0.0,
            "is_reading": False,
            "attention_score": 0.0,
            "blink_detected": False,
            "fatigue_score": 0.0,
        }
        
        # Update total time
        if self._last_update_time > 0:
            dt = timestamp - self._last_update_time
            if dt > 0 and dt < 0.5:  # Valid time delta
                self._total_time += dt
                
                # Check focus condition: fixation AND low velocity
                if is_fixation and velocity < 0.05:
                    self._focused_time += dt
        
        self._last_update_time = timestamp

        if self._last_position is not None:
            dx = x - self._last_position[0]
            dy = y - self._last_position[1]
            dt = timestamp - self._last_timestamp

            if velocity > self.saccade_velocity_threshold:
                self._saccades += 1
                analytics["saccade_detected"] = True
                self._pending_line_change = False

            # Only detect line changes during fixations (for stability)
            if is_fixation and not analytics["saccade_detected"]:
                if abs(dy) > self.line_change_threshold:
                    if not self._pending_line_change:
                        self._line_changes += 1
                        self._current_line_y = y
                        analytics["line_changed"] = True
                        self._pending_line_change = True
                else:
                    self._pending_line_change = False

            if dx > 0.02 and abs(dy) < 0.03 and dt > 0:
                self._left_to_right_movements += 1
                analytics["left_to_right"] = True

            self._movement_history.append((dx, dy, velocity, timestamp))

        is_reading = self._detect_reading_pattern(velocity, y)
        if is_reading and not self._reading_active:
            self._reading_active = True
            self._reading_start_time = timestamp
        elif not is_reading and self._reading_active:
            self._reading_active = False
            self._reading_time += timestamp - self._reading_start_time

        analytics["is_reading"] = is_reading

        if self._reading_active:
            reading_duration = timestamp - self._reading_start_time
            if reading_duration > 0:
                estimated_words = (self._line_changes * self.words_per_line +
                                  self._left_to_right_movements)
                wpm = (estimated_words / reading_duration) * 60.0
                analytics["reading_speed"] = min(wpm, 800)
        
        # Calculate attention score
        if self._total_time > 0:
            self._attention_score = (self._focused_time / self._total_time) * 100.0
        analytics["attention_score"] = round(self._attention_score, 1)
        
        # Detect blink from EAR
        if ear < 0.12:  # Blink threshold
            analytics["blink_detected"] = True
            self._blink_count += 1
            
        # Calculate fatigue score based on blink rate and attention
        # Normal blink rate: 15-20 per minute
        if self._total_time > 60:  # After 1 minute
            blink_rate = (self._blink_count / self._total_time) * 60.0
            if blink_rate > 25:
                self._fatigue_score = min(100, (blink_rate - 15) * 4)
            elif blink_rate < 8:
                self._fatigue_score = min(100, (8 - blink_rate) * 6)
            else:
                self._fatigue_score = max(0, 100 - abs(blink_rate - 18) * 5)
        analytics["fatigue_score"] = round(self._fatigue_score, 1)

        self._last_position = (x, y)
        self._last_timestamp = timestamp
        self._last_velocity = velocity

        return analytics

    def _detect_reading_pattern(self, velocity: float, y: float) -> bool:
        if len(self._movement_history) < 10:
            return False

        if not (self.reading_velocity_min < velocity < self.reading_velocity_max):
            return False

        recent_y_positions = [m[1] for m in list(self._movement_history)[-10:]]
        if len(recent_y_positions) > 1:
            vertical_trend = recent_y_positions[-1] - recent_y_positions[0]
            if vertical_trend < -0.01:
                return False

        recent_velocities = [m[2] for m in list(self._movement_history)[-20:]]
        velocity_changes = sum(1 for i in range(1, len(recent_velocities))
                              if abs(recent_velocities[i] - recent_velocities[i-1]) > 0.02)

        return velocity_changes > 3

    def get_metrics(self) -> Dict[str, Any]:
        return {
            "total_saccades": self._saccades,
            "line_changes": self._line_changes,
            "left_to_right_movements": self._left_to_right_movements,
            "reading_time_seconds": self._reading_time,
            "reading_active": self._reading_active,
            "estimated_words_read": (self._line_changes * self.words_per_line +
                                    self._left_to_right_movements),
            "attention_score": round(self._attention_score, 1),
            "total_time_seconds": round(self._total_time, 1),
            "focused_time_seconds": round(self._focused_time, 1),
            "blink_count": self._blink_count,
            "fatigue_score": round(self._fatigue_score, 1),
        }

    def reset(self) -> None:
        self._last_position = None
        self._last_timestamp = 0.0
        self._last_velocity = 0.0
        self._current_line_y = 0.0
        self._line_changes = 0
        self._saccades = 0
        self._left_to_right_movements = 0
        self._reading_time = 0.0
        self._reading_active = False
        self._reading_start_time = 0.0
        self._movement_history.clear()
        self._pending_line_change = False
        self._total_time = 0.0
        self._focused_time = 0.0
        self._last_update_time = 0.0
        self._attention_score = 0.0
        self._blink_count = 0
        self._fatigue_score = 0.0


class TemporalBuffer:
    """Buffer for last N predictions to provide temporal stability."""
    
    def __init__(self, buffer_size: int = 5):
        self.buffer_size = buffer_size
        self._buffer_x: deque = deque(maxlen=buffer_size)
        self._buffer_y: deque = deque(maxlen=buffer_size)
        
    def update(self, x: float, y: float) -> Tuple[float, float]:
        self._buffer_x.append(x)
        self._buffer_y.append(y)
        
        # Return averaged output
        avg_x = sum(self._buffer_x) / len(self._buffer_x)
        avg_y = sum(self._buffer_y) / len(self._buffer_y)
        
        return avg_x, avg_y
    
    def reset(self) -> None:
        self._buffer_x.clear()
        self._buffer_y.clear()


class GazePipeline:
    """Full smoothing chain with reading-area awareness and optimized filters.
    
    Enhanced with temporal buffer for stability.
    """
    
    def __init__(self) -> None:
        self.damper = VelocityDamper(max_jump=0.08, blend=0.2)
        self.kalman = AdaptiveKalman()
        self.ema = AdaptiveEMA(alpha_slow=0.02, alpha_fast=0.18)
        self.dead_zone = DeadZoneGate(threshold=0.01)
        self.final_smooth = FinalSmoothing(alpha=0.15)
        self.frame_skip = FrameSkipFilter(skip_frames=2)
        self.fixation = FixationDetector(radius=0.04, min_frames=8)
        self.reading = ReadingAnalytics(line_change_threshold=0.10)
        self.temporal_buffer = TemporalBuffer(buffer_size=5)  # NEW: Temporal stability buffer
        self._last_x: float = 0.5
        self._last_y: float = 0.5
        self._last_local_x: float = 0.5
        self._last_local_y: float = 0.5
        self._last_timestamp: float = 0.0

    def process(
        self, rx: float, ry: float, timestamp: float
    ) -> Tuple[float, float, bool, Optional[Tuple[float, float]], Dict[str, Any]]:
        # Apply frame skip for stability
        if not self.frame_skip.should_update():
            return self._last_x, self._last_y, False, None, {}
        
        rx, ry = self.damper.update(rx, ry)
        kx, ky = self.kalman.update(rx, ry)
        vel = self.kalman.velocity
        ex, ey = self.ema.update(kx, ky, velocity=vel)
        gx, gy = self.dead_zone.update(ex, ey)
        fx, fy = self.final_smooth.update(gx, gy)  # Final smoothing
        self._last_x = fx
        self._last_y = fy
        is_fix, fix_c = self.fixation.update(fx, fy, timestamp)
        
        # Pass fixation status to reading analytics for stable line detection
        reading_analytics = self.reading.update(fx, fy, vel, timestamp, is_fixation=is_fix)
        return fx, fy, is_fix, fix_c, reading_analytics

    def process_local(self, rx: float, ry: float, timestamp: float) -> Tuple[float, float]:
        """Process prediction in reading-area local coordinates with temporal buffer."""
        if not self.frame_skip.should_update():
            return self._last_local_x, self._last_local_y
        
        rx, ry = self.damper.update(rx, ry)
        kx, ky = self.kalman.update(rx, ry)
        vel = self.kalman.velocity
        ex, ey = self.ema.update(kx, ky, velocity=vel)
        gx, gy = self.dead_zone.update(ex, ey)
        fx, fy = self.final_smooth.update(gx, gy)
        
        # Apply temporal buffer for stability
        fx, fy = self.temporal_buffer.update(fx, fy)
        
        self._last_local_x = fx
        self._last_local_y = fy
        return fx, fy

    def reset(self) -> None:
        self.damper.reset()
        self.kalman.reset()
        self.ema.reset()
        self.dead_zone.reset()
        self.final_smooth.reset()
        self.fixation.reset()
        self.reading.reset()
        self.temporal_buffer.reset()
        self._last_x = self._last_y = 0.5
        self._last_local_x = self._last_local_y = 0.5
        self._last_timestamp = 0.0

    @property
    def last_position(self) -> Tuple[float, float]:
        return self._last_x, self._last_y
    
    @property
    def last_local_position(self) -> Tuple[float, float]:
        return self._last_local_x, self._last_local_y

    def get_reading_metrics(self) -> Dict[str, Any]:
        return self.reading.get_metrics()


# ══════════════════════════════════════════════════════════════════
# SECTION 2 — LANDMARK CONSTANTS
# ══════════════════════════════════════════════════════════════════

LEFT_IRIS = [474, 475, 476, 477]
RIGHT_IRIS = [469, 470, 471, 472]
LEFT_CORNER_INNER = 133
LEFT_CORNER_OUTER = 33
RIGHT_CORNER_INNER = 362
RIGHT_CORNER_OUTER = 263
LEFT_UPPER_LID = 159
LEFT_LOWER_LID = 145
RIGHT_UPPER_LID = 386
RIGHT_LOWER_LID = 374
NOSE_TIP = 1
FACE_TOP = 10
FACE_BOTTOM = 152
FACE_LEFT = 234
FACE_RIGHT = 454


# ══════════════════════════════════════════════════════════════════
# SECTION 3 — FEATURE EXTRACTION (Enhanced)
# ══════════════════════════════════════════════════════════════════

def _ear(upper: np.ndarray, lower: np.ndarray,
         left: np.ndarray, right: np.ndarray) -> float:
    vert = float(np.linalg.norm(upper - lower))
    horiz = max(float(np.linalg.norm(left - right)), 1e-6)
    return vert / horiz


def extract_features(
    landmarks,
    img_w: int,
    img_h: int,
    prev_features: Optional[np.ndarray] = None,
    dt: float = 0.033,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], float]:
    try:
        lm = landmarks.landmark

        def pt(idx: int) -> np.ndarray:
            return np.array(
                [lm[idx].x * img_w, lm[idx].y * img_h], dtype=np.float32)

        fl = pt(FACE_LEFT)
        fr = pt(FACE_RIGHT)
        ft = pt(FACE_TOP)
        fb = pt(FACE_BOTTOM)
        fw = max(float(np.linalg.norm(fr - fl)), 1.0)
        fh = max(float(np.linalg.norm(fb - ft)), 1.0)

        def norm(p: np.ndarray) -> np.ndarray:
            return (p - fl) / np.array([fw, fh], dtype=np.float32)

        li = np.mean([pt(i) for i in LEFT_IRIS], axis=0).astype(np.float32)
        ri = np.mean([pt(i) for i in RIGHT_IRIS], axis=0).astype(np.float32)
        lin = pt(LEFT_CORNER_INNER)
        lout = pt(LEFT_CORNER_OUTER)
        rin = pt(RIGHT_CORNER_INNER)
        rout = pt(RIGHT_CORNER_OUTER)
        lup = pt(LEFT_UPPER_LID)
        ldo = pt(LEFT_LOWER_LID)
        rup = pt(RIGHT_UPPER_LID)
        rdo = pt(RIGHT_LOWER_LID)
        nose = pt(NOSE_TIP)

        li_n = norm(li)
        ri_n = norm(ri)
        no_n = norm(nose)
        mid_n = (li_n + ri_n) * 0.5

        lew = max(float(np.linalg.norm(lin - lout)), 1.0)
        leh = max(float(np.linalg.norm(lup - ldo)), 1.0)
        lix = float(np.dot(li - lout, lin - lout)) / (lew ** 2)
        liy = float(li[1] - lup[1]) / leh

        rew = max(float(np.linalg.norm(rin - rout)), 1.0)
        reh = max(float(np.linalg.norm(rup - rdo)), 1.0)
        rix = float(np.dot(ri - rout, rin - rout)) / (rew ** 2)
        riy = float(ri[1] - rup[1]) / reh

        lear = _ear(lup, ldo, lout, lin)
        rear = _ear(rup, rdo, rout, rin)

        l_inner_ratio = float(np.linalg.norm(li - lin)) / lew
        l_outer_ratio = float(np.linalg.norm(li - lout)) / lew
        r_inner_ratio = float(np.linalg.norm(ri - rin)) / rew
        r_outer_ratio = float(np.linalg.norm(ri - rout)) / rew

        fw_fh_ratio = fw / fh
        iris_y_dev = float(mid_n[1] - no_n[1])
        
        # NEW FEATURES: Iris velocity (requires previous frame)
        iris_velocity_x = 0.0
        iris_velocity_y = 0.0
        if prev_features is not None and dt > 0:
            # Previous iris positions are at indices 0,1 for left and 2,3 for right
            prev_li_x = prev_features[0]
            prev_li_y = prev_features[1]
            prev_ri_x = prev_features[2]
            prev_ri_y = prev_features[3]
            
            # Average iris velocity
            iris_velocity_x = ((li_n[0] - prev_li_x) + (ri_n[0] - prev_ri_x)) / (2.0 * dt)
            iris_velocity_y = ((li_n[1] - prev_li_y) + (ri_n[1] - prev_ri_y)) / (2.0 * dt)
            
            # Clamp extreme velocities
            iris_velocity_x = np.clip(iris_velocity_x, -5.0, 5.0)
            iris_velocity_y = np.clip(iris_velocity_y, -5.0, 5.0)
        
        # NEW FEATURES: Eye center coordinates
        eye_center_x = float(mid_n[0])
        eye_center_y = float(mid_n[1])
        
        # NEW FEATURES: Eye distance (between left and right iris)
        eye_distance = float(np.linalg.norm(li_n - ri_n))
        
        # NEW FEATURES: Eye angle (atan2)
        eye_angle = float(math.atan2(ri_n[1] - li_n[1], ri_n[0] - li_n[0]))
        
        # NEW FEATURES: Temporal difference (if previous frame available)
        temporal_diff_x = 0.0
        temporal_diff_y = 0.0
        if prev_features is not None:
            # Compare current nose position with previous
            prev_nose_x = prev_features[12] if len(prev_features) > 12 else no_n[0]
            prev_nose_y = prev_features[13] if len(prev_features) > 13 else no_n[1]
            temporal_diff_x = no_n[0] - prev_nose_x
            temporal_diff_y = no_n[1] - prev_nose_y
        
        # Base features (22 features)
        base_feats = np.array([
            float(li_n[0]), float(li_n[1]),
            float(ri_n[0]), float(ri_n[1]),
            float(mid_n[0]), float(mid_n[1]),
            lix, liy,
            rix, riy,
            lear, rear,
            float(no_n[0]), float(no_n[1]),
            float(np.linalg.norm(li - nose)) / fw,
            float(np.linalg.norm(ri - nose)) / fw,
            l_inner_ratio, l_outer_ratio,
            r_inner_ratio, r_outer_ratio,
            fw_fh_ratio,
            iris_y_dev,
        ], dtype=np.float32)
        
        # Append new features (7 additional features)
        new_features = np.array([
            iris_velocity_x, iris_velocity_y,
            eye_center_x, eye_center_y,
            eye_distance, eye_angle,
            temporal_diff_x, temporal_diff_y,
        ], dtype=np.float32)
        
        # Combine all features
        feats = np.concatenate([base_feats, new_features])
        
        return feats, no_n.astype(np.float32), min(lear, rear)

    except Exception as exc:
        logger.debug("extract_features failed: %s", exc)
        return None, None, 1.0


# ══════════════════════════════════════════════════════════════════
# SECTION 4 — CALIBRATION BANK (Reading-Area Aware)
# ══════════════════════════════════════════════════════════════════

class CalibrationBank:
    """Stores (feature, local_target) pairs with quality filters."""
    
    MAX_VAR_THRESHOLD = 0.12
    EAR_BLINK_THRESHOLD = 0.12
    MIN_FEATURE_DISTANCE = 0.05

    def __init__(self) -> None:
        self._features: List[np.ndarray] = []
        self._targets: List[List[float]] = []
        self._recent: List[np.ndarray] = []
        self._recent_maxlen = 10
        self._last_accepted_feature: Optional[np.ndarray] = None
        self._per_point_counts: Dict[int, int] = {}
        self._current_point_idx: int = 0
        self._csv_file = "calibration_data.csv"
        self._csv_initialized = False
        self.samples_per_point = 8
        self._prev_features: Optional[np.ndarray] = None  # For velocity calculation

    def _init_csv(self) -> None:
        if not self._csv_initialized:
            file_exists = os.path.isfile(self._csv_file)
            if not file_exists:
                # Extended feature names (30 features total)
                feature_names = [
                    'left_iris_x', 'left_iris_y',
                    'right_iris_x', 'right_iris_y',
                    'mid_iris_x', 'mid_iris_y',
                    'left_iris_rel_x', 'left_iris_rel_y',
                    'right_iris_rel_x', 'right_iris_rel_y',
                    'left_ear', 'right_ear',
                    'nose_x', 'nose_y',
                    'left_iris_nose_dist', 'right_iris_nose_dist',
                    'left_inner_ratio', 'left_outer_ratio',
                    'right_inner_ratio', 'right_outer_ratio',
                    'face_ratio', 'iris_y_deviation',
                    'iris_velocity_x', 'iris_velocity_y',
                    'eye_center_x', 'eye_center_y',
                    'eye_distance', 'eye_angle',
                    'temporal_diff_x', 'temporal_diff_y'
                ]
                
                headers = ['timestamp', 'point_index', 'target_x', 'target_y', 'ear_value'] + feature_names
                
                with open(self._csv_file, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(headers)
            self._csv_initialized = True

    def save_to_csv(self, feats: np.ndarray, target_x: float, target_y: float, 
                    ear: float, point_idx: int) -> None:
        try:
            self._init_csv()
            feature_list = feats.tolist()
            row = [
                datetime.now().isoformat(),
                point_idx,
                target_x,
                target_y,
                ear
            ] + feature_list
            
            with open(self._csv_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(row)
        except Exception as e:
            logger.error(f"Failed to save to CSV: {e}")

    def set_current_point(self, idx: int) -> None:
        self._current_point_idx = idx
        if idx not in self._per_point_counts:
            self._per_point_counts[idx] = 0

    def try_add(
        self,
        feats: np.ndarray,
        local_x: float,
        local_y: float,
        ear: float,
    ) -> Tuple[bool, str]:
        if ear < self.EAR_BLINK_THRESHOLD:
            return False, "blink"
        
        if self._last_accepted_feature is not None:
            feat_dist = np.mean(np.abs(feats - self._last_accepted_feature))
            if feat_dist < self.MIN_FEATURE_DISTANCE:
                return False, "feature_duplicate"
        
        self._recent.append(feats.copy())
        if len(self._recent) > self._recent_maxlen:
            self._recent.pop(0)
        
        if len(self._recent) >= 4:
            stack = np.stack(self._recent)
            mean_std = float(np.mean(np.std(stack, axis=0)))
            if mean_std > self.MAX_VAR_THRESHOLD:
                return False, "unstable"
        
        self._features.append(feats.copy())
        self._targets.append([float(local_x), float(local_y)])
        self._last_accepted_feature = feats.copy()
        self._per_point_counts[self._current_point_idx] = self._per_point_counts.get(self._current_point_idx, 0) + 1
        
        self.save_to_csv(feats, local_x, local_y, ear, self._current_point_idx)
        
        return True, "accepted"
    
    def get_point_count(self, idx: int) -> int:
        return self._per_point_counts.get(idx, 0)

    def clear(self) -> None:
        self._features.clear()
        self._targets.clear()
        self._recent.clear()
        self._last_accepted_feature = None
        self._per_point_counts.clear()

    def reset_recent(self) -> None:
        self._recent.clear()
        self._last_accepted_feature = None

    @property
    def n(self) -> int:
        return len(self._features)

    @property
    def features(self) -> np.ndarray:
        return np.array(self._features, dtype=np.float32)

    @property
    def targets(self) -> np.ndarray:
        return np.array(self._targets, dtype=np.float32)


# ══════════════════════════════════════════════════════════════════
# SECTION 5 — SAFE OUTLIER REJECTION
# ══════════════════════════════════════════════════════════════════

def _reject_outliers_mahalanobis_safe(
    X: np.ndarray,
    Y: np.ndarray,
    threshold: float = 5.5,
    min_keep_ratio: float = 0.25,
    min_keep_abs: int = 30,
) -> Tuple[np.ndarray, np.ndarray]:
    n_samples = len(X)
    
    if n_samples < 15:
        return X, Y
    
    try:
        mean = X.mean(axis=0)
        cov = np.cov(X.T)
        reg = np.eye(cov.shape[0]) * 1e-6
        cov_reg = cov + reg
        inv_cov = np.linalg.pinv(cov_reg)
        
        distances = np.array([mahalanobis(x, mean, inv_cov) for x in X])
        
        if np.any(np.isnan(distances)) or np.any(np.isinf(distances)):
            logger.warning("NaN/inf in Mahalanobis distances, skipping outlier removal")
            return X, Y
        
        mask = distances < threshold
        n_keep = int(mask.sum())
        min_keep = max(min_keep_abs, int(min_keep_ratio * n_samples))
        
        if n_keep < min_keep:
            logger.warning(f"Outlier removal would keep {n_keep}/{n_samples} samples, using all")
            return X, Y
        
        if n_keep < n_samples:
            logger.info(f"Removed {n_samples - n_keep} outliers, kept {n_keep}")
            return X[mask], Y[mask]
        
        return X, Y
        
    except Exception as exc:
        logger.warning(f"Outlier removal failed: {exc}, using all samples")
        return X, Y


# ══════════════════════════════════════════════════════════════════
# SECTION 6 — MODELS (Reading-Area Optimized with XGBoost)
# ══════════════════════════════════════════════════════════════════

def _build_ridge_model() -> Pipeline:
    """Primary: Ridge regression with polynomial features."""
    return Pipeline([
        ("sc", StandardScaler()),
        ("poly", PolynomialFeatures(degree=2, include_bias=False)),
        ("ridge", Ridge(alpha=1.5, fit_intercept=True)),  # Increased alpha for stability
    ])


def _build_xgboost_model() -> XGBRegressor:
    """XGBoost model for high accuracy."""
    return XGBRegressor(
        n_estimators=200,
        max_depth=6,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_alpha=0.1,
        reg_lambda=1.0,
        random_state=42,
        n_jobs=-1,
        verbosity=0
    )


def _build_mlp_model() -> Pipeline:
    """Optional MLP ensemble for higher accuracy."""
    return Pipeline([
        ("sc", StandardScaler()),
        ("mlp", MLPRegressor(
            hidden_layer_sizes=(128, 64, 32),
            activation="tanh",
            solver="adam",
            max_iter=3000,
            learning_rate_init=8e-4,
            random_state=42,
            early_stopping=True,
            validation_fraction=0.15,
            n_iter_no_change=50,
            alpha=1e-3,
        )),
    ])


def _calibration_quality_score_reading(
    model: Pipeline,
    X: np.ndarray,
    Y: np.ndarray,
    n_folds: int = 5
) -> float:
    """
    Compute quality score specifically for reading area performance.
    Penalizes vertical error more heavily (critical for line tracking).
    """
    if len(X) < 10:
        return 0.0
    
    try:
        from sklearn.model_selection import KFold
        kf = KFold(n_splits=min(n_folds, len(X)), shuffle=True, random_state=42)
        
        errors_x = []
        errors_y = []
        
        for train_idx, val_idx in kf.split(X):
            X_train, X_val = X[train_idx], X[val_idx]
            Y_train, Y_val = Y[train_idx], Y[val_idx]
            
            m = _build_ridge_model()
            m.fit(X_train, Y_train)
            pred = m.predict(X_val)
            
            # Compute errors in local reading-area coordinates
            err_x = np.mean(np.abs(pred[:, 0] - Y_val[:, 0]))
            err_y = np.mean(np.abs(pred[:, 1] - Y_val[:, 1]))
            errors_x.append(err_x)
            errors_y.append(err_y)
        
        mean_err_x = np.mean(errors_x)
        mean_err_y = np.mean(errors_y)
        
        # Weight vertical error more heavily (3x penalty)
        weighted_error = (mean_err_x + 3.0 * mean_err_y) / 4.0
        
        # Convert error to score: target 0.02 error = 100, 0.10 error = 0
        score = max(0.0, min(100.0, 100.0 * (1.0 - (weighted_error / 0.08))))
        
        logger.info(f"Calibration quality - X error: {mean_err_x:.3f}, Y error: {mean_err_y:.3f}, score: {score:.1f}")
        
        return score
        
    except Exception as exc:
        logger.warning(f"Quality score calculation failed: {exc}")
        return 0.0


# ══════════════════════════════════════════════════════════════════
# SECTION 7 — GAZE ENGINE (Reading-Area Aware with XGBoost Ensemble)
# ══════════════════════════════════════════════════════════════════

class GazeEngine:
    """Owns calibration bank, model(s), and gaze prediction for reading area.
    
    Enhanced with XGBoost model and ensemble prediction.
    """
    
    CALIBRATION_FILE = "calibration_v6_reading.pkl"
    
    def __init__(self) -> None:
        self.bank = CalibrationBank()
        self.is_calibrated = False
        self._ridge: Optional[Pipeline] = None
        self._xgboost: Optional[XGBRegressor] = None
        self._mlp: Optional[Pipeline] = None
        self._use_ensemble = False
        self._base_nose_pos: Optional[np.ndarray] = None
        self.sensitivity = 1.0
        self.quality_score = 0.0
        
        # Reading area bounds (screen coordinates)
        self.reading_left: float = 0.0
        self.reading_top: float = 0.0
        self.reading_width: float = 1.0
        self.reading_height: float = 1.0
        
        self._load()
    
    def set_reading_area(self, left: float, top: float, width: float, height: float) -> None:
        """Set the reading area bounds for coordinate conversion."""
        self.reading_left = left
        self.reading_top = top
        self.reading_width = max(width, 0.01)
        self.reading_height = max(height, 0.01)
        logger.info(f"Reading area set: ({left:.3f}, {top:.3f}) {width:.3f}x{height:.3f}")
    
    def screen_to_local(self, screen_x: float, screen_y: float) -> Tuple[float, float]:
        """Convert screen coordinates to reading-area local coordinates."""
        local_x = (screen_x - self.reading_left) / self.reading_width
        local_y = (screen_y - self.reading_top) / self.reading_height
        return np.clip(local_x, 0.0, 1.0), np.clip(local_y, 0.0, 1.0)
    
    def local_to_screen(self, local_x: float, local_y: float) -> Tuple[float, float]:
        """Convert reading-area local coordinates to screen coordinates."""
        screen_x = self.reading_left + local_x * self.reading_width
        screen_y = self.reading_top + local_y * self.reading_height
        return np.clip(screen_x, 0.0, 1.0), np.clip(screen_y, 0.0, 1.0)
    
    def add_sample(
        self, feats: np.ndarray, local_x: float, local_y: float, ear: float, point_idx: int
    ) -> Tuple[bool, str]:
        self.bank.set_current_point(point_idx)
        return self.bank.try_add(feats, local_x, local_y, ear)
    
    def reset_point_buffer(self) -> None:
        self.bank.reset_recent()
    
    def train_model(self) -> Tuple[bool, str]:
        n_raw = self.bank.n
        logger.info(f"Train model: {n_raw} raw samples")
        
        if n_raw < 20:
            return False, f"Need >= 20 samples, have {n_raw}"
        
        X_raw, Y_raw = self.bank.features, self.bank.targets
        
        # Safe outlier removal
        X_clean, Y_clean = _reject_outliers_mahalanobis_safe(X_raw, Y_raw, threshold=5.5)
        n_clean = len(X_clean)
        
        logger.info(f"After outlier filtering: {n_clean} samples")
        
        if n_clean >= 15:
            X_train, Y_train = X_clean, Y_clean
            logger.info(f"Using cleaned data with {n_clean} samples")
        else:
            X_train, Y_train = X_raw, Y_raw
            logger.warning(f"Cleaned data insufficient ({n_clean}), using raw {n_raw} samples")
        
        # Compute base nose position for head compensation
        self._base_nose_pos = np.array(
            [X_train[:, 12].mean(), X_train[:, 13].mean()], dtype=np.float32)
        
        # Train ridge model
        self._ridge = _build_ridge_model()
        self._ridge.fit(X_train, Y_train)
        logger.info("Ridge model trained")
        
        # Train XGBoost model (always if enough samples)
        if len(X_train) >= 30:
            try:
                # XGBoost expects targets for both X and Y, we'll train two models or one multi-output
                # For simplicity and better accuracy, we'll train separate models for X and Y
                self._xgboost = XGBRegressor(
                    n_estimators=150,
                    max_depth=5,
                    learning_rate=0.05,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    reg_alpha=0.1,
                    reg_lambda=1.0,
                    random_state=42,
                    n_jobs=-1,
                    verbosity=0
                )
                # Train on full feature set for both coordinates
                # We'll use multi-output approach by training one model
                self._xgboost.fit(X_train, Y_train)
                logger.info("XGBoost model trained")
            except Exception as exc:
                logger.warning(f"XGBoost training failed: {exc}")
                self._xgboost = None
        
        # Train MLP ensemble if enough samples
        if len(X_train) >= 80:
            try:
                self._mlp = _build_mlp_model()
                self._mlp.fit(X_train, Y_train)
                self._use_ensemble = True
                logger.info("MLP ensemble trained")
            except Exception as exc:
                logger.warning(f"MLP training failed: {exc}")
                self._use_ensemble = False
        else:
            self._use_ensemble = False
        
        # Compute quality score
        if self._ridge is not None:
            self.quality_score = _calibration_quality_score_reading(self._ridge, X_train, Y_train)
        logger.info(f"Quality score: {self.quality_score:.1f}/100")
        
        self.is_calibrated = True
        self._save()
        
        ensemble_status = " + XGBoost"
        if self._use_ensemble:
            ensemble_status += " + MLP"
        return True, f"OK - {len(X_train)} samples, quality {self.quality_score:.0f}/100{ensemble_status}"
    
    def predict_local_gaze(
        self, feats: np.ndarray, nose: np.ndarray
    ) -> Optional[Tuple[float, float]]:
        """Predict gaze in reading-area local coordinates using ensemble."""
        if not self.is_calibrated or self._ridge is None:
            return None
        
        try:
            adj = self._apply_head_comp(feats, nose)
            inp = adj.reshape(1, -1)
            
            # Ridge prediction
            ridge_pred = self._ridge.predict(inp)
            ridge_x = float(ridge_pred[0, 0])
            ridge_y = float(ridge_pred[0, 1])
            
            # XGBoost prediction (if available)
            xgb_x, xgb_y = ridge_x, ridge_y
            if self._xgboost is not None:
                try:
                    xgb_pred = self._xgboost.predict(inp)
                    xgb_x = float(xgb_pred[0, 0])
                    xgb_y = float(xgb_pred[0, 1])
                except Exception as exc:
                    logger.debug(f"XGBoost prediction failed: {exc}")
            
            # MLP prediction (if available)
            mlp_x, mlp_y = ridge_x, ridge_y
            if self._use_ensemble and self._mlp is not None:
                try:
                    mlp_pred = self._mlp.predict(inp)
                    mlp_x = float(mlp_pred[0, 0])
                    mlp_y = float(mlp_pred[0, 1])
                except Exception:
                    pass
            
            # Ensemble prediction with weights: 0.5 * Ridge + 0.3 * XGBoost + 0.2 * MLP
            local_x = 0.5 * ridge_x + 0.3 * xgb_x + 0.2 * mlp_x
            local_y = 0.5 * ridge_y + 0.3 * xgb_y + 0.2 * mlp_y
            
            # Apply sensitivity
            local_x = np.clip(0.5 + (local_x - 0.5) * self.sensitivity, 0.0, 1.0)
            local_y = np.clip(0.5 + (local_y - 0.5) * self.sensitivity, 0.0, 1.0)
            
            return local_x, local_y
            
        except Exception as exc:
            logger.debug(f"predict_gaze error: {exc}")
            # Fallback: try just ridge if ensemble fails
            try:
                ridge_pred = self._ridge.predict(adj.reshape(1, -1))
                return float(ridge_pred[0, 0]), float(ridge_pred[0, 1])
            except:
                return None
    
    def _apply_head_comp(self, feats: np.ndarray, nose: np.ndarray) -> np.ndarray:
        """Apply head compensation using nose deviation."""
        if self._base_nose_pos is None:
            return feats
        # Enhanced head compensation with adaptive scaling
        dx = float((nose[0] - self._base_nose_pos[0]) * 0.55)
        dy = float((nose[1] - self._base_nose_pos[1]) * 0.55)
        adj = feats.copy()
        # Adjust iris and mid points
        for i in [0, 2, 4, 22, 24]:  # Added eye center indices
            if i < len(adj):
                adj[i] -= dx
        for i in [1, 3, 5, 23, 25]:  # Added eye center indices
            if i < len(adj):
                adj[i] -= dy
        return adj
    
    def reset_calibration(self) -> None:
        self.bank.clear()
        self.is_calibrated = False
        self._ridge = None
        self._xgboost = None
        self._mlp = None
        self._use_ensemble = False
        self._base_nose_pos = None
        self.quality_score = 0.0
    
    def _save(self) -> None:
        try:
            with open(self.CALIBRATION_FILE, "wb") as fh:
                pickle.dump({
                    "ridge": self._ridge,
                    "xgboost": self._xgboost,
                    "mlp": self._mlp,
                    "use_ensemble": self._use_ensemble,
                    "base_nose_pos": self._base_nose_pos,
                    "quality_score": self.quality_score,
                    "reading_area": {
                        "left": self.reading_left,
                        "top": self.reading_top,
                        "width": self.reading_width,
                        "height": self.reading_height
                    }
                }, fh)
            logger.info(f"Calibration saved to {self.CALIBRATION_FILE}")
        except Exception as exc:
            logger.warning(f"Calibration save failed: {exc}")
    
    def _load(self) -> None:
        if not os.path.exists(self.CALIBRATION_FILE):
            return
        try:
            with open(self.CALIBRATION_FILE, "rb") as fh:
                d = pickle.load(fh)
            self._ridge = d["ridge"]
            self._xgboost = d.get("xgboost")
            self._mlp = d.get("mlp")
            self._use_ensemble = bool(d.get("use_ensemble", False))
            self._base_nose_pos = d.get("base_nose_pos")
            self.quality_score = float(d.get("quality_score", 0.0))
            
            # Load reading area if available
            if "reading_area" in d:
                ra = d["reading_area"]
                self.reading_left = ra.get("left", 0.0)
                self.reading_top = ra.get("top", 0.0)
                self.reading_width = ra.get("width", 1.0)
                self.reading_height = ra.get("height", 1.0)
            
            self.is_calibrated = True
            logger.info(f"Loaded calibration - quality {self.quality_score:.1f}/100, reading area: {self.reading_width:.2f}x{self.reading_height:.2f}")
        except Exception as exc:
            logger.warning(f"Calibration load failed: {exc}")


# ══════════════════════════════════════════════════════════════════
# SECTION 8 — MEDIAPIPE SINGLETON
# ══════════════════════════════════════════════════════════════════

_face_mesh = mp.solutions.face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.70,
    min_tracking_confidence=0.70,
)

# ══════════════════════════════════════════════════════════════════
# SECTION 9 — SHARED STATE
# ══════════════════════════════════════════════════════════════════

gaze_engine = GazeEngine()
_pipeline = GazePipeline()
_prev_features_for_velocity: Optional[np.ndarray] = None  # For velocity calculation

camera_lock = threading.Lock()
camera_running = False

cal_lock = threading.Lock()
cal_collecting = False
cal_target_local_x = 0.0
cal_target_local_y = 0.0
cal_samples_needed = 0
cal_samples_done = 0
cal_current_point_idx = 0


# ══════════════════════════════════════════════════════════════════
# SECTION 10 — CAMERA LOOP
# ══════════════════════════════════════════════════════════════════

def _camera_loop(socketio_instance) -> None:
    global camera_running, cal_collecting, cal_samples_done, _prev_features_for_velocity

    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)

    if not cap.isOpened():
        logger.error("Cannot open camera")
        camera_running = False
        return

    logger.info("Camera thread started")

    encode_params = [cv2.IMWRITE_JPEG_QUALITY, 82]
    target_dt = 1.0 / 30.0
    frame_n = 0
    last_valid_local = (0.5, 0.5)
    last_valid_screen = (0.5, 0.5)
    last_frame_time = time.time()

    while camera_running:
        t0 = time.perf_counter()
        current_time = time.time()
        dt = current_time - last_frame_time
        last_frame_time = current_time

        ret, frame = cap.read()
        if not ret:
            time.sleep(0.02)
            continue

        frame = cv2.flip(frame, 1)
        h, w = frame.shape[:2]
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = _face_mesh.process(rgb)

        payload: dict = {
            "status": "no_face",
            "gaze": None,
            "gaze_local": None,
            "debug": {},
            "cal_count": gaze_engine.bank.n,
            "fixation": None,
        }

        if result.multi_face_landmarks:
            feats, nose, ear = extract_features(
                result.multi_face_landmarks[0], w, h, 
                prev_features=_prev_features_for_velocity,
                dt=dt
            )

            if feats is not None:
                # Store features for next frame's velocity calculation
                _prev_features_for_velocity = feats.copy()
                
                with cal_lock:
                    if cal_collecting and cal_samples_done < cal_samples_needed:
                        accepted, reason = gaze_engine.add_sample(
                            feats, cal_target_local_x, cal_target_local_y, ear, cal_current_point_idx
                        )
                        if accepted:
                            cal_samples_done += 1
                            logger.info(f"Sample accepted: point {cal_current_point_idx}, samples {cal_samples_done}/{cal_samples_needed}")
                            socketio_instance.emit("cal_sample_progress", {
                                "point_idx": cal_current_point_idx,
                                "samples_collected": cal_samples_done,
                                "samples_needed": cal_samples_needed,
                                "last_reason": reason
                            })
                        else:
                            logger.debug(f"Sample rejected: {reason}")
                        
                        if cal_samples_done >= cal_samples_needed:
                            logger.info(f"Calibration point {cal_current_point_idx} completed!")
                            socketio_instance.emit("cal_point_done", {
                                "point_idx": cal_current_point_idx,
                                "total": gaze_engine.bank.n,
                            })
                            cal_collecting = False

                if gaze_engine.is_calibrated:
                    pred_local = gaze_engine.predict_local_gaze(feats, nose)
                    if pred_local is not None:
                        local_x, local_y = _pipeline.process_local(pred_local[0], pred_local[1], current_time)
                        last_valid_local = (local_x, local_y)
                        
                        screen_x, screen_y = gaze_engine.local_to_screen(local_x, local_y)
                        last_valid_screen = (screen_x, screen_y)
                        
                        # Get fixation status for reading analytics
                        is_fix, fix_c = _pipeline.fixation.update(local_x, local_y, current_time)
                        
                        reading_analytics = _pipeline.reading.update(
                            local_x, local_y, 
                            _pipeline.kalman.velocity, 
                            current_time,
                            is_fixation=is_fix,
                            ear=ear  # Pass EAR for blink detection
                        )
                        
                        payload["status"] = "tracking"
                        payload["gaze"] = {
                            "x": round(screen_x, 4),
                            "y": round(screen_y, 4)
                        }
                        payload["gaze_local"] = {
                            "x": round(local_x, 4),
                            "y": round(local_y, 4)
                        }
                        payload["fixation"] = None
                        
                        if is_fix and fix_c:
                            payload["fixation"] = {
                                "x": round(fix_c[0], 4),
                                "y": round(fix_c[1], 4)
                            }
                        
                        # Get comprehensive metrics
                        metrics = _pipeline.get_reading_metrics()
                        
                        payload["debug"] = {
                            "raw_local_x": round(pred_local[0], 4),
                            "raw_local_y": round(pred_local[1], 4),
                            "smooth_local_x": round(local_x, 4),
                            "smooth_local_y": round(local_y, 4),
                            "screen_x": round(screen_x, 4),
                            "screen_y": round(screen_y, 4),
                            "velocity": round(_pipeline.kalman.velocity, 4),
                            "ear": round(ear, 3),
                            "samples": gaze_engine.bank.n,
                            "quality": round(gaze_engine.quality_score, 1),
                            "fixating": is_fix,
                            "reading_active": reading_analytics.get("is_reading", False),
                            "reading_speed": round(reading_analytics.get("reading_speed", 0), 1),
                            "saccade_detected": reading_analytics.get("saccade_detected", False),
                            "line_changed": reading_analytics.get("line_changed", False),
                            "attention_score": metrics.get("attention_score", 0),
                            "fatigue_score": metrics.get("fatigue_score", 0),
                            "reading_area": {
                                "left": gaze_engine.reading_left,
                                "top": gaze_engine.reading_top,
                                "width": gaze_engine.reading_width,
                                "height": gaze_engine.reading_height
                            }
                        }
                        
                        payload["reading"] = {
                            "is_reading": reading_analytics.get("is_reading", False),
                            "reading_speed_wpm": round(reading_analytics.get("reading_speed", 0), 1),
                            "saccades": metrics["total_saccades"],
                            "line_changes": metrics["line_changes"],
                            "left_to_right_movements": metrics["left_to_right_movements"],
                            "reading_time_seconds": round(metrics["reading_time_seconds"], 1),
                            "attention_score": metrics.get("attention_score", 0),
                            "total_time_seconds": metrics.get("total_time_seconds", 0),
                            "focused_time_seconds": metrics.get("focused_time_seconds", 0),
                            "blink_count": metrics.get("blink_count", 0),
                            "fatigue_score": metrics.get("fatigue_score", 0),
                        }
                    else:
                        payload["status"] = "tracking"
                        payload["gaze"] = {
                            "x": round(last_valid_screen[0], 4),
                            "y": round(last_valid_screen[1], 4)
                        }
                        payload["gaze_local"] = {
                            "x": round(last_valid_local[0], 4),
                            "y": round(last_valid_local[1], 4)
                        }
                else:
                    payload["status"] = "uncalibrated"
            else:
                payload["status"] = "low_confidence"
                payload["gaze"] = {
                    "x": round(last_valid_screen[0], 4),
                    "y": round(last_valid_screen[1], 4)
                }
                payload["gaze_local"] = {
                    "x": round(last_valid_local[0], 4),
                    "y": round(last_valid_local[1], 4)
                }
        else:
            payload["gaze"] = {
                "x": round(last_valid_screen[0], 4),
                "y": round(last_valid_screen[1], 4)
            }
            payload["gaze_local"] = {
                "x": round(last_valid_local[0], 4),
                "y": round(last_valid_local[1], 4)
            }

        frame_n += 1
        if frame_n % 2 == 0:
            prev = cv2.resize(frame, (320, 240))
            _, buf = cv2.imencode(".jpg", prev, encode_params)
            payload["preview"] = base64.b64encode(buf.tobytes()).decode("ascii")

        payload = convert_to_serializable(payload)
        socketio_instance.emit("gaze_update", payload)

        elapsed = time.perf_counter() - t0
        sleep_t = target_dt - elapsed
        if sleep_t > 0:
            time.sleep(sleep_t)

    cap.release()
    logger.info("Camera stopped")


def _start_camera(socketio_instance) -> None:
    global camera_running
    with camera_lock:
        if not camera_running:
            camera_running = True
            t = threading.Thread(
                target=_camera_loop, args=(socketio_instance,), daemon=True)
            t.start()
            logger.info("Camera thread launched")


# ══════════════════════════════════════════════════════════════════
# SECTION 11 — FLASK + SOCKETIO
# ══════════════════════════════════════════════════════════════════

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "gaze_v6_2024")
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="gevent")


@socketio.on("connect")
def on_connect():
    logger.info("Client connected: %s", request.sid)
    _start_camera(socketio)
    emit("init", {
        "calibrated": gaze_engine.is_calibrated,
        "sensitivity": gaze_engine.sensitivity,
        "quality_score": gaze_engine.quality_score,
        "reading_area": {
            "left": gaze_engine.reading_left,
            "top": gaze_engine.reading_top,
            "width": gaze_engine.reading_width,
            "height": gaze_engine.reading_height
        },
        "samples_per_point": gaze_engine.bank.samples_per_point
    })


@socketio.on("disconnect")
def on_disconnect():
    logger.info("Client disconnected: %s", request.sid)


@socketio.on("start_cal_point")
def on_start_cal_point(data: dict):
    global cal_collecting, cal_target_local_x, cal_target_local_y
    global cal_samples_needed, cal_samples_done, cal_current_point_idx
    
    with cal_lock:
        reading_left = float(data.get("reading_left", 0.0))
        reading_top = float(data.get("reading_top", 0.0))
        reading_width = float(data.get("reading_width", 1.0))
        reading_height = float(data.get("reading_height", 1.0))
        
        if reading_width > 0 and reading_height > 0:
            gaze_engine.set_reading_area(reading_left, reading_top, reading_width, reading_height)
        
        cal_target_local_x = float(data.get("local_x", data.get("screen_x", 0.5)))
        cal_target_local_y = float(data.get("local_y", data.get("screen_y", 0.5)))
        
        cal_samples_needed = int(data.get("n_samples", gaze_engine.bank.samples_per_point))
        cal_samples_done = 0
        cal_current_point_idx = int(data.get("point_idx", 0))
        cal_collecting = True
        gaze_engine.reset_point_buffer()
        
        logger.info(f"Cal point {cal_current_point_idx}: local ({cal_target_local_x:.3f}, {cal_target_local_y:.3f}), need {cal_samples_needed} samples")
    
    emit("cal_point_started", {"ok": True, "point_idx": cal_current_point_idx})


@socketio.on("stop_cal_point")
def on_stop_cal_point():
    global cal_collecting
    with cal_lock:
        cal_collecting = False


@socketio.on("train_model")
def on_train():
    logger.info("Training requested - %d samples", gaze_engine.bank.n)
    success, message = gaze_engine.train_model()
    if success:
        _pipeline.reset()
    
    result_data = convert_to_serializable({
        "success": success,
        "n_samples": gaze_engine.bank.n,
        "message": message,
        "quality_score": gaze_engine.quality_score,
    })
    emit("train_result", result_data)
    logger.info("Train result: %s - %s", success, message)


@socketio.on("reset_calibration")
def on_reset():
    global cal_collecting, _prev_features_for_velocity
    with cal_lock:
        cal_collecting = False
    gaze_engine.reset_calibration()
    _pipeline.reset()
    _prev_features_for_velocity = None
    emit("calibration_reset", {})
    logger.info("Calibration reset")


@socketio.on("set_sensitivity")
def on_sensitivity(data: dict):
    val = float(np.clip(data.get("value", 1.0), 0.3, 2.0))
    gaze_engine.sensitivity = val
    logger.info("Sensitivity -> %.2f", val)


@socketio.on("set_samples_per_point")
def on_set_samples_per_point(data: dict):
    val = int(data.get("value", 8))
    val = max(4, min(32, val))
    gaze_engine.bank.samples_per_point = val
    logger.info(f"Samples per point set to: {val}")
    emit("samples_per_point_updated", {"value": val})


@socketio.on("get_snap_line")
def on_snap_line(data: dict):
    try:
        local_y = float(data.get("gaze_local_y", data.get("gaze_y", 0.5)))
        lines = [float(y) for y in data["lines"]]
        if not lines:
            emit("snap_line_result", {"index": -1})
            return
        dists = [abs(local_y - ly) for ly in lines]
        idx = int(np.argmin(dists))
        emit("snap_line_result", {"index": idx, "line_y": lines[idx]})
    except Exception as exc:
        emit("snap_line_result", {"index": -1, "error": str(exc)})


@socketio.on("get_reading_metrics")
def on_get_reading_metrics():
    metrics = _pipeline.get_reading_metrics()
    emit("reading_metrics", convert_to_serializable(metrics))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/status")
def status():
    return jsonify(convert_to_serializable({
        "calibrated": gaze_engine.is_calibrated,
        "cal_samples": gaze_engine.bank.n,
        "quality_score": gaze_engine.quality_score,
        "camera": camera_running,
        "reading_metrics": _pipeline.get_reading_metrics(),
        "reading_area": {
            "left": gaze_engine.reading_left,
            "top": gaze_engine.reading_top,
            "width": gaze_engine.reading_width,
            "height": gaze_engine.reading_height
        },
        "samples_per_point": gaze_engine.bank.samples_per_point
    }))


@app.route("/export_calibration")
def export_calibration():
    csv_file = "calibration_data.csv"
    if os.path.exists(csv_file):
        return send_file(csv_file, as_attachment=True, download_name=f"calibration_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
    else:
        return jsonify({"error": "No calibration data available"}), 404


@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file"}), 400

    f = request.files["file"]
    fname = (f.filename or "").lower()
    lines: List[str] = []

    try:
        if fname.endswith(".txt"):
            raw = f.read().decode("utf-8", "replace")
            lines = [l for l in raw.splitlines() if l.strip()]

        elif fname.endswith(".pdf"):
            if not HAS_PYMUPDF:
                return jsonify({"error": "pip install PyMuPDF"}), 400
            doc = fitz.open(stream=f.read(), filetype="pdf")
            for page in doc:
                for line in page.get_text("text").splitlines():
                    if line.strip():
                        lines.append(line.strip())

        elif fname.endswith(".docx"):
            if not HAS_DOCX:
                return jsonify({"error": "pip install python-docx"}), 400
            doc = DocxDocument(io.BytesIO(f.read()))
            lines = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

        else:
            return jsonify({"error": "Unsupported format (.txt/.pdf/.docx only)"}), 400

    except Exception as exc:
        logger.exception("File processing error")
        return jsonify({"error": str(exc)}), 500

    return jsonify({"lines": lines})


if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=False)